-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 10, 2022 at 09:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_buku`
--

CREATE TABLE `tabel_buku` (
  `isbn` varchar(50) NOT NULL,
  `namabuku` varchar(50) NOT NULL,
  `penulisbuku` varchar(50) NOT NULL,
  `tahunterbitbuku` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_buku`
--

INSERT INTO `tabel_buku` (`isbn`, `namabuku`, `penulisbuku`, `tahunterbitbuku`) VALUES
('978-602-3333-33-4', 'As A Man Thinketh', 'James Allen', '2015'),
('978-602-5413-87-1', 'Berani Tidak Disukai', 'Ichiro Kishimi & Fumitake Koga', '2018'),
('978-602-1234-56-7', 'Berpikir dan Berjiwa Besar', 'David J. Schwartz', '2015'),
('978-602-7870-41-3', 'Dilan', 'Pidi Baiq', '2014'),
('978-602-7777-78-7', 'Etos Kerja', 'Desmon Ginting', '2020'),
('978-602-0956-66-3', 'Filosofi Teras', 'Henry Manampiring', '2017'),
('978-602-8855-14-3', 'Jika Kita Tak Pernah Jadi Apa-Apa', 'Alvi Syahrin', '2017'),
('978-602-3854-16-5', 'Mans Search for Meaning', 'Viktor E. Frankl', '2017'),
('978-602-0632-42-1', 'Mantappu Jiwa', 'Jerome Polin Sijabat', '2019'),
('978-602-7634-45-1', 'Merawat Luka Batin', 'Dr.Jiemi Ardian', '2016'),
('978-602-6724-00-8', 'Obat Minder', 'Alam Bacthiar', '2016'),
('978-602-1133-89-0', 'Rich Dad Poor Dad', 'Robert T. Kiyosaki', '2015'),
('978-602-6675-98-8', 'Sapiens', 'Yuval Noah Harari', '2015'),
('978-602-1122-34-5', 'Sebuah Seni Untuk Bersikap Bodo Amat', 'Mark Manson', '2018'),
('978-602-5674-75-2', 'Seni Mengatasi Depresi', 'William Andromeda', '2012'),
('978-602-5555-77-9', 'Seni Menjaga Kewarasan Hidup', 'Sebastian Wahyu', '2017'),
('978-602-5108-78-9', 'Start With Why', 'Simon Sinek', '2013'),
('978-602-1342-09-0', 'Sukses Dari Diri Sendiri', 'Ihab Majid', '2017'),
('978-602-4321-09-8', 'Tak Apa-Apa Tak Sempurna', 'Brene Brown', '2020'),
('978-602-5142-51-4', 'Think and Grow Rich', 'Napoleon Hill', '2019'),
('978-602-4433-65-5', 'Thinking, Fast and Slow', 'Daniel Kahneman', '2014'),
('978-602-8537-59-9', 'Untuk Apa Aku Ada di Dunia Ini', 'Rick Warren', '2002'),
('978-602-9687-99-9', 'You Do You', 'Fellexandro Ruby', '2019');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_pengguna`
--

CREATE TABLE `tabel_pengguna` (
  `id_pengguna` varchar(10) NOT NULL,
  `nama_pengguna` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_pengguna`
--

INSERT INTO `tabel_pengguna` (`id_pengguna`, `nama_pengguna`) VALUES
('12345', 'ayo'),
('10303', 'Vladio');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_rating`
--

CREATE TABLE `tabel_rating` (
  `id_pengguna` varchar(10) NOT NULL,
  `nama_pengguna` varchar(50) NOT NULL,
  `ratingbuku` int(1) NOT NULL,
  `namabuku` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabel_rating`
--

INSERT INTO `tabel_rating` (`id_pengguna`, `nama_pengguna`, `ratingbuku`, `namabuku`) VALUES
('12345', 'ayo', 9, 'Mantappu Jiwa'),
('12345', 'ayo', 9, 'Mantappu Jiwa'),
('12345', 'ayo', 9, 'Dilan'),
('12345', 'ayo', 5, 'Mantappu Jiwa'),
('12345', 'ayo', 8, 'Dilan'),
('10303', 'Vladio', 7, 'Dilan'),
('10303', 'Vladio', 9, 'Dilan'),
('12345', 'ayo', 9, 'Dilan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_buku`
--
ALTER TABLE `tabel_buku`
  ADD UNIQUE KEY `namabuku` (`namabuku`);

--
-- Indexes for table `tabel_pengguna`
--
ALTER TABLE `tabel_pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `nama_pengguna` (`nama_pengguna`);

--
-- Indexes for table `tabel_rating`
--
ALTER TABLE `tabel_rating`
  ADD KEY `id_pengguna` (`id_pengguna`,`namabuku`,`nama_pengguna`),
  ADD KEY `nama_pengguna` (`nama_pengguna`),
  ADD KEY `namabuku` (`namabuku`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tabel_rating`
--
ALTER TABLE `tabel_rating`
  ADD CONSTRAINT `tabel_rating_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `tabel_pengguna` (`id_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tabel_rating_ibfk_2` FOREIGN KEY (`nama_pengguna`) REFERENCES `tabel_pengguna` (`nama_pengguna`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tabel_rating_ibfk_3` FOREIGN KEY (`namabuku`) REFERENCES `tabel_buku` (`namabuku`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
