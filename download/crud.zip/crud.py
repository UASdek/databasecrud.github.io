from tkinter import *
from tkinter import ttk
from tkinter import messagebox


import mysql.connector as mysql

class loginpage:
    def __init__(self,root):
        self.root = root
        self.root.title =("LOGIN UNTUK MMENCARI")
        self.root.geometry("1000x700+0+0")
        self.loginform()
        
    def loginform(self):
        Frame_login =(Frame(self.root,bg="Black"))
        Frame_login.place(x="0",y="0",height="700",width="1366")
        
        Frame_input=(Frame(self.root,bg="White"))
        Frame_input.place(x="320",y="130",height="450",width="350")
        
        label1= Label(Frame_input,text="Login Disini",font=('impact',32,'bold'),fg="black",bg="White")
        label1.place(x=75,y=20)
        
        label2 = Label(Frame_input,text="ID Pengguna",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label2.place(x=30,y=95)
        
        self.id_text = Entry(Frame_input,font=("times new roman",13,'bold'),bg='lightgray')
        self.id_text.place(x=30,y=145,height=35,width=270)
        
        label3 = Label(Frame_input,text="Nama Pengguna",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label3.place(x=30,y=195)
        
        self.nama_text = Entry(Frame_input,font=("times new roman",13,'bold'),bg='lightgray')
        self.nama_text.place(x=30,y=245,height=35,width=270)
        
        tambah_but = Button(Frame_input,text="Buat ID Baru?",command=self.tambahid,cursor='hand2',font=('times new roman',12),bg='White',fg='black',bd=0)
        tambah_but.place(x=125,y=305)
        
        login_but = Button(Frame_input,text="LOGIN",command=self.login,cursor='hand2',font=('times new roman',18),bg='Black',fg='White',bd=0,height=1,width=15)
        login_but.place(x=90,y=340)
        
    def loginbutclear(self):
        self.nama_text.delete(0, END)
        self.id_text.delete(0, END)
            
        
    def login(self):
         if self.nama_text.get() == "" or self.id_text.get() == "":
            messagebox.showerror("ERORR","Harap Masukan Nama dan ID",parent=self.root)
         else:
            try: 
                con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
                cur=con.cursor()
                cur.execute(" SELECT * from tabel_pengguna WHERE id_pengguna=%s and nama_pengguna=%s",
                            (self.id_text.get(),self.nama_text.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Erorr","Nama Atau Id Salah")
                    self.loginbutclear()
                    self.nama_text.focus()
                else:    
                    self.caribuku()                                
                    con.close()                    
            except Exception as es:                
                messagebox.showerror("Erorr",f"Error Due To : {str(es)}",parent=self.root)
                self.loginbutclear()
                
                
    def tambahid(self):
        Frame_tambahid =(Frame(self.root,bg="Black"))
        Frame_tambahid.place(x="0",y="0",height="450",width="1366")
        
        Frame_tambahid_input=(Frame(self.root,bg="White"))
        Frame_tambahid_input.place(x="320",y="130",height="450",width="350")
        
        label6 = Label(Frame_tambahid_input,text="SIGN UP",font=('Goudy old style',20,'bold'),fg="black",bg="White")
        label6.place(x=45,y=20)
        
        label4 = Label(Frame_tambahid_input,text="ID Baru",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label4.place(x=30,y=95)
        
        self.nama_baru_text = Entry(Frame_tambahid_input,font=("times new roman",13,'bold'),bg='lightgray')
        self.nama_baru_text.place(x=30,y=145,height=35,width=270)
        
        label5 = Label(Frame_tambahid_input,text="Nama Baru",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label5.place(x=30,y=195)
        
        self.id_baru_text = Entry(Frame_tambahid_input,font=("times new roman",13,'bold'),bg='lightgray')
        self.id_baru_text.place(x=30,y=245,height=35,width=270)
        
        tambah_but = Button(Frame_tambahid_input,text="SIGN UP",command=self.idbaru,cursor='hand2',font=('times new roman',18),bg='Black',fg='White',bd=0,height=1,width=15)
        tambah_but.place(x=90,y=340)
        
        back_but = Button(Frame_tambahid_input,text="Kembali",command=self.loginform,cursor='hand2',font=('times new roman',10),bg='Black',fg='White',bd=0,height=1,width=10)
        back_but.place(x=260,y=400)
        
        
        
    def idbaru(self):
        if self.nama_baru_text.get() == "" or self.id_baru_text.get() == "":
            messagebox.showerror("ERORR","Harap Masukan Nama dan ID",parent=self.root)
        else:
            try:
                con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
                cur=con.cursor()
                cur.execute("SELECT * tabel_pengguna WHERE id_pengguna=%s",
                            (self.id_baru_text.get()))
                row = cur.fetchone()
                if row != None :
                    messagebox.showerror("Erorr","ID sudah ada, Buat ID baru",parent=self.root)                
                    self.id_baru_text.focus()    
                else:                                        
                    cur.execute("inser into tabel_pengguna(id_pengguna,nama_pengguna",(self.id_baru_text.get(),self.nama_baru_text.get()))                    
                    messagebox.showinfo("SUCCSESS","SING UP Berhasil, Kembali ke halaman Login")
                    self.tambahclear()                    
            except Exception as es:
                messagebox.showerror("Erorr",f"Error Due To : {str(es)}")                               
                
    def tambahclear(self):
        self.id_baru_text.delete(0,END)
        self.nama_baru_text.delete(0,END)

    def caribuku(self):
        Frame_caribuku =(Frame(self.root,bg="Black"))
        Frame_caribuku.place(x="0",y="0",height="700",width="1366")
        
        Frame_caribuku_input=(Frame(self.root,bg="White"))
        Frame_caribuku_input.place(x="252",y="120",height="450",width="450")
        
        label8 = Label(Frame_caribuku_input,text="Judul Buku",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label8.place(x=20,y=20)
        
        self.judulbuku = Entry(Frame_caribuku_input,font=('Goudy old style',18,'bold'),fg="black",bg="White")
        self.judulbuku.place(x=20,y=70)
        
        label1 = Label(Frame_caribuku_input,text="Tahun Terbit",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label1.place(x=20,y=120)
        
        self.tahunterbit = Entry(Frame_caribuku_input,font=('Goudy old style',18,'bold'),fg="black",bg="White")
        self.tahunterbit.place(x=20,y=170)
        
        label2 = Label(Frame_caribuku_input,text="Penulis Buku",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label2.place(x=20,y=220)
        
        self.penulisbuku = Entry(Frame_caribuku_input,font=('Goudy old style',18,'bold'),fg="black",bg="White")
        self.penulisbuku.place(x=20,y=270)
        
        label3 = Label(Frame_caribuku_input,text="ISBN",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label3.place(x=20,y=320)
        
        self.isbn = Entry(Frame_caribuku_input,font=('Goudy old style',18,'bold'),fg="black",bg="White")
        self.isbn.place(x=20,y=370)
                
        search_but = Button(Frame_caribuku_input,text="CARI",command=self.search,cursor='hand2',font=('times new roman',15),bg='Black',fg='White',bd=0,height=1,width=10)
        search_but.place(x=300,y=220)
        
        back_but = Button(Frame_caribuku_input,text="HOME",command=self.loginform,cursor='hand2',font=('times new roman',15),bg='Black',fg='White',bd=0,height=1,width=10)
        back_but.place(x=300,y=320)      
        
    def search(self):
         if self.judulbuku.get() == "" or self.tahunterbit.get() == ""or self.penulisbuku.get() == ""or self.isbn.get() == "":
            messagebox.showerror("ERORR","Harap Isi Semua kolom",parent=self.root)
         else:
            try:
                con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
                cur=con.cursor()
                cur.execute("SELECT * From tabel_buku WHERE namabuku=%s AND tahunterbitbuku=%s AND penulisbuku=%s AND isbn=%s ",
                            (self.judulbuku.get(),self.tahunterbit.get(),self.penulisbuku.get(),self.isbn.get()))
                row = cur.fetchone() 
                if row == None:
                       messagebox.showerror("KOSONG","Buku Yang Anda Cari Tidak Ada Disini",parent=self.root)
                else:
                    judul = self.judulbuku.get()
                    tahun = self.tahunterbit.get()
                    penulis=self.penulisbuku.get()
                    noisbn =self.isbn.get()
                    self.detail(judul,tahun,penulis,noisbn)            
            except Exception as es:
                messagebox.showerror("Erorr",f"Error Due To : {str(es)}")                                
    
    
    def bukuclear(self):
        self.judulbuku.delete(0,END)
        self.tahunterbit.delete(0,END)
        self.penulisbuku.delete(0,END)
        self.isbn.delete(0,END)
        
    def detail(self,judul,tahun,penulis,noisbn):
                
        judul=judul
        tahun=tahun
        penulis=penulis
        noisbn=noisbn
        
        Frame_detail_cari =Frame(self.root,bg="Black")
        Frame_detail_cari.place(x="0",y="0",height="700",width="1366")
        
        Frame_data= Frame(self.root,bg="white")
        Frame_data.place(x="252",y="100",height="200",width="550")
        
        self.tabel = ttk.Treeview(Frame_data,columns=(1,2,3,4,5),show="headings",height=9)
        
        self.tabel.heading(1,text="Judul Buku")
        self.tabel.heading(2,text="Tahun Terbit")
        self.tabel.heading(3,text="Penulis")
        self.tabel.heading(4,text="ISBN")
        self.tabel.heading(5,text="Rating")    
        
        self.tabel.column(1,width=100,anchor=CENTER)
        self.tabel.column(2,width=100,anchor=CENTER)
        self.tabel.column(3,width=100,anchor=CENTER)
        self.tabel.column(4,width=100,anchor=CENTER)
        self.tabel.column(5,width=100,anchor=CENTER)
        
        self.tabel.place(x="0",y="0",width=550)
        
        con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
        cur=con.cursor()
        cur.execute("Select AVG(ratingbuku) FROM tabel_rating WHERE namabuku=%s",(judul,))
        rating=cur.fetchall()
        
        self.tabel.insert("",'end',iid=1,values=(judul,tahun,penulis,noisbn,rating))
        
        
        Frame_detail=Frame(self.root,bg="White")
        Frame_detail.place(x="252",y="400",height="200",width="550")
        
        self.scrollx=ttk.Scrollbar(Frame_detail,orient=VERTICAL)
        self.scrolly=ttk.Scrollbar(Frame_detail,orient=HORIZONTAL)
        
        self.tblkomen = ttk.Treeview(Frame_detail,columns=(1,2,3),show="headings",height=9,xscrollcommand=self.scrollx.set,yscrollcommand=self.scrolly.set)
        
        self.scrollx.pack(side=RIGHT,fill=Y)
        self.scrolly.pack(side=BOTTOM,fill=X)
        
        self.tblkomen.heading(1,text="ID")
        self.tblkomen.heading(2,text="Nama")
        self.tblkomen.heading(3,text="Rating")
        
        self.tblkomen.column(1,width=100,anchor=CENTER)
        self.tblkomen.column(2,width=100,anchor=CENTER)
        self.tblkomen.column(3,width=100,anchor=CENTER)
        
        self.tblkomen.place(x="0",y="0",width=550)
        
        con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
        cur=con.cursor()
        cur.execute("Select * from tabel_rating where namabuku=%s",(judul,))
        self.row=cur.fetchall()
        
        if len(self.row)!=0:
            self.tblkomen.delete(*self.tblkomen.get_children())
            for i in self.row:
                self.tblkomen.insert('','end',values=i)
        
        but_addrate = Button(Frame_data,text="ADD RATE",command=self.rate,cursor='hand2',font=('times new roman',10),bg='Black',fg='White',bd=0,height=1,width=10,)
        but_addrate.place(x="450",y="170")
        
        back_but = Button(Frame_data,text="HOME",command=self.caribuku,cursor='hand2',font=('times new roman',10),bg='Black',fg='White',bd=0,height=1,width=10)
        back_but.place(x=350,y=170)
        
    def rate(self):
        
        Frame_rate =Frame(self.root,bg="Black")
        Frame_rate.place(x="0",y="0",height="700",width="1366")
        
        Frame_rate_input= Frame(self.root,bg="white")
        Frame_rate_input.place(x="252",y="200",height="120",width="300")
        
        label2 = Label(Frame_rate_input,text="Berikan Rate",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label2.place(x=20,y=40)
        
        label3 = Label(Frame_rate_input,text="*",font=('Goudy old style',18,'bold'),fg="black",bg="White")
        label3.place(x=200,y=40)
        
        star=['1','2','3','4','5','6','7','8','9']        
        self.starrate=ttk.Combobox(Frame_rate_input,values=star,font=('Goudy old style',18,'bold'))        
        self.starrate.place(x=165,y=40,height=35,width=35)
        self.starrate.config(state="readonly")
        
        add_but = Button(Frame_rate_input,text="ADD",command=self.rateadd,cursor='hand2',font=('times new roman',10),bg='Black',fg='White',bd=0,height=1,width=10)
        add_but.place(x=220,y=40)
        
        pul_but = Button(Frame_rate_input,text="KEMBALI",command=self.caribuku,cursor='hand2',font=('times new roman',10),bg='Black',fg='White',bd=0,height=1,width=10)
        pul_but.place(x=220,y=80)
    
    def rateadd(self):
        if self.starrate.get() == "":
            messagebox.showerror("ERORR","Tidak Boleh Kosong",parent=self.root)
        else:
            try: 
                con = mysql.connect(host='localhost',database='perpustakaan',user='root',password='',port=3306,autocommit=True)
                cur=con.cursor()
                cur.execute("INSERT INTO tabel_rating(id_pengguna,namabuku,nama_pengguna,ratingbuku)values(%s,%s,%s,%s)",(self.id_text.get(),self.judulbuku.get(),self.nama_text.get(),self.starrate.get()))
                messagebox.showinfo("SUCCSESS","Silahkan Kembali")
                
            except Exception as es:                
                messagebox.showerror("Erorr",f"Error Due To : {str(es)}",parent=self.root) 
       
                
                            
                
        
        
        
        
        
            
        
                
        
        
        
        
        
                          
root=Tk()        
Aplikasi = loginpage(root)
root.mainloop()